# CodeBridge Native 1.0 — Android Studio project

هذه نسخة Native أولية متقدمة نسبيًا، تتصل بـ Debian عبر SSH/SFTP، وليست واجهة code-server ولا نسخة Microsoft VS Code.

## الوظائف
- اتصال SSH من التابلت إلى هاتف Debian.
- مستعرض ملفات ومجلدات SFTP، تنقل للأعلى وفتح المجلدات.
- فتح الملفات النصية UTF-8 حتى 3MB، تحريرها وحفظها على الهاتف.
- تبويبات للملفات المفتوحة.
- تلوين Syntax بسيط للكلمات الشائعة والتعليقات والسلاسل والأرقام.
- Undo/Redo، Ctrl+S وCtrl+Z وCtrl+Y.
- Terminal تفاعلي عبر SSH مع إرسال الأوامر واستقبال المخرجات.
- دعم إدخال لوحة المفاتيح والماوس الأساسي من خلال عناصر Android الأصلية.

## حدود مهمة
ليست IDE كاملة بمستوى VS Code: لا يوجد LSP أو autocomplete متقدم أو debugger أو Git UI أو مدير extensions أو محرر متعدد المؤشرات. التلوين بسيط وليس parser كامل. الملفات الثنائية/الكبيرة غير مناسبة للعرض. الماوس يعتمد على سلوك Android القياسي. هذه نسخة مصدرية لمعاينة عملية وليست APK مختبرًا.

## أمان SSH
هذا المشروع يضبط `StrictHostKeyChecking=no` لتسهيل تجربة LAN فقط. هذا غير مناسب للإنتاج لأنه لا يتحقق من هوية الخادم. استخدم شبكة موثوقة فقط، وكلمة مرور قوية، ولا تعرض SSH للإنترنت. قبل الاستخدام الدائم يجب إضافة التحقق من بصمة host key أو استخدام مفاتيح SSH موثوقة.

## إعداد Debian على الهاتف
داخل Debian:
```bash
sudo apt update
sudo apt install openssh-server
sudo service ssh start
hostname -I
```
إذا لم يوجد sudo استخدم root أو مدير الحزم المناسب. تأكد أن SSH يستمع على الشبكة:
```bash
ss -tlnp | grep ':22'
```
يجب أن يكون الهاتف والتابلت على نفس Wi-Fi أو hotspot، وألا يكون عزل العملاء (AP isolation) يمنع الاتصال.

## استخدام التطبيق
- Host: عنوان IP للهاتف من `hostname -I` (مثال 192.168.1.20)
- Port: 22
- SSH user/password: بيانات مستخدم Debian
- اضغط Connect SSH
- اكتب مسار مجلد مثل `/home/USERNAME` ثم Go
- افتح ملفًا من القائمة، عدّل ثم Save
- زر Terminal يفتح جلسة shell

## بناء APK
1. نزّل Android Studio وثبّته على كمبيوتر.
2. فك ضغط ZIP.
3. Android Studio > Open > اختر مجلد `CodeBridge-Native-Full` (المجلد الذي يحتوي settings.gradle).
4. انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طُلب.
5. من القائمة Build > Build Bundle(s) / APK(s) > Build APK(s).
6. بعد النجاح اضغط locate أو افتح:
   `app/build/outputs/apk/debug/app-debug.apk`
7. انقل APK للتابلت وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.

يمكن أيضًا استخدام Android Studio على كمبيوتر Linux/Windows/macOS. بناء Android APK يحتاج Android SDK وJDK؛ لا أستطيع تأكيد نجاح البناء قبل تجربته في بيئة Android SDK فعلية.

## ملاحظات
- المشروع يستخدم Gradle plugin 8.7.3 وSDK 35.
- اتصال SSH منفصل عن code-server: لا يستخدم بورت 8080.
- احفظ تغييراتك باستمرار؛ لا توجد استعادة تلقائية من انقطاع الاتصال.
