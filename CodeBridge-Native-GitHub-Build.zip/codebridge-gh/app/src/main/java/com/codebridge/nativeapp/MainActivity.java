package com.codebridge.nativeapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.*;
import android.text.style.ForegroundColorSpan;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.jcraft.jsch.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(17,24,39), PANEL=Color.rgb(31,41,55), EDIT=Color.rgb(10,15,25),
        FG=Color.rgb(229,231,235), MUTED=Color.rgb(156,163,175), BLUE=Color.rgb(59,130,246),
        GREEN=Color.rgb(134,239,172), ORANGE=Color.rgb(251,191,36);
    LinearLayout root, top, tabs, content, bottom;
    EditText host,port,user,password,path,editor,terminalInput;
    TextView status, terminalOutput;
    ScrollView terminalScroll;
    Button connectBtn;
    Session session;
    ChannelSftp sftp;
    ChannelShell shell;
    OutputStream shellIn;
    InputStream shellOut;
    ExecutorService io=Executors.newSingleThreadExecutor();
    Handler main=new Handler(Looper.getMainLooper());
    String currentPath="/home", currentFile=null;
    final LinkedHashMap<String,String> openFiles=new LinkedHashMap<>();
    final ArrayList<String> tabOrder=new ArrayList<>();
    final ArrayDeque<String> undo=new ArrayDeque<>(), redo=new ArrayDeque<>();
    boolean suppressWatch=false, terminalVisible=false;
    int activeTab=-1;

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);buildUi();}

    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    EditText edit(String hint,boolean single){EditText e=new EditText(this);e.setSingleLine(single);e.setTextColor(FG);e.setHintTextColor(MUTED);e.setHint(hint);e.setTextSize(14);e.setPadding(10,5,10,5);e.setBackgroundColor(PANEL);return e;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setPadding(6,0,6,0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));b.setOnClickListener(v->r.run());return b;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void buildUi(){
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(7,5,7,5);
        TextView title=text("CodeBridge Native",18,FG);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        TextView sub=text("SSH • SFTP • Native editor • Terminal",11,MUTED);root.addView(sub);
        LinearLayout r=row();host=edit("Debian phone IP",true);r.addView(host,new LinearLayout.LayoutParams(0,44,2));
        port=edit("22",true);port.setText("22");r.addView(port,new LinearLayout.LayoutParams(0,44,1));root.addView(r);
        r=row();user=edit("SSH user",true);r.addView(user,new LinearLayout.LayoutParams(0,44,1));
        password=edit("Password",true);password.setInputType(129);r.addView(password,new LinearLayout.LayoutParams(0,44,1));root.addView(r);
        connectBtn=button("Connect SSH",()->connect());root.addView(connectBtn);
        status=text("Not connected • use same Wi-Fi/hotspot",11,MUTED);status.setPadding(4,4,4,4);root.addView(status);
        r=row();path=edit("/home",true);path.setText("/home");r.addView(path,new LinearLayout.LayoutParams(0,42,1));
        r.addView(button("Go",()->browse(path.getText().toString())));
        r.addView(button("Up",()->goParent()));r.addView(button("New",()->newFileDialog()));root.addView(r);
        HorizontalScrollView tabScroll=new HorizontalScrollView(this);tabs=row();tabScroll.addView(tabs);root.addView(tabScroll);
        content=new LinearLayout(this);content.setOrientation(1);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        bottom=row();
        bottom.addView(button("Save",()->saveCurrent()),new LinearLayout.LayoutParams(0,42,1));
        bottom.addView(button("Undo",()->undoEdit()),new LinearLayout.LayoutParams(0,42,1));
        bottom.addView(button("Redo",()->redoEdit()),new LinearLayout.LayoutParams(0,42,1));
        bottom.addView(button("Terminal",()->toggleTerminal()),new LinearLayout.LayoutParams(0,42,1));
        bottom.addView(button("Refresh",()->{if(terminalVisible)readTerminal();else browse(currentPath);}),new LinearLayout.LayoutParams(0,42,1));
        root.addView(bottom);
        editor=edit("Open a file from the remote explorer…",false);editor.setGravity(Gravity.TOP|Gravity.LEFT);editor.setTypeface(Typeface.MONOSPACE);editor.setTextSize(13);editor.setBackgroundColor(EDIT);
        editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setHorizontallyScrolling(true);editor.setPadding(10,10,10,10);
        editor.addTextChangedListener(new TextWatcher(){String before="";
            public void beforeTextChanged(CharSequence s,int st,int c,int a){before=s.toString();}
            public void onTextChanged(CharSequence s,int st,int beforeCount,int count){}
            public void afterTextChanged(Editable e){if(suppressWatch)return;if(currentFile!=null){openFiles.put(currentFile,e.toString());if(!before.equals(e.toString())){undo.push(before);if(undo.size()>100)undo.removeLast();redo.clear();}}}
        });
        showEditor();setContentView(root);
    }
    void setStatus(String s){main.post(()->status.setText(s));}
    boolean connected(){return session!=null&&session.isConnected()&&sftp!=null&&sftp.isConnected();}
    void connect(){
        String h=host.getText().toString().trim(),u=user.getText().toString(),pw=password.getText().toString();int p=22;
        try{p=Integer.parseInt(port.getText().toString());}catch(Exception ignored){}final int pp=p;
        if(h.isEmpty()||u.isEmpty()||pw.isEmpty()){setStatus("Enter IP, SSH username and password");return;}
        setStatus("Connecting SSH…");
        io.execute(()->{try{
            disconnect();JSch j=new JSch();session=j.getSession(u,h,pp);session.setPassword(pw);
            Properties cfg=new Properties();cfg.put("StrictHostKeyChecking","no");session.setConfig(cfg);session.connect(15000);
            Channel c=session.openChannel("sftp");c.connect(10000);sftp=(ChannelSftp)c;
            setStatus("Connected to "+h+":"+pp);browse("/home");
        }catch(Exception e){setStatus("SSH error: "+e.getMessage());}});
    }
    void disconnect(){try{if(shell!=null)shell.disconnect();}catch(Exception e){}try{if(sftp!=null)sftp.disconnect();}catch(Exception e){}try{if(session!=null)session.disconnect();}catch(Exception e){}shell=null;sftp=null;session=null;}
    void browse(String p){
        if(!connected()){setStatus("Connect SSH first");return;} if(p==null||p.trim().isEmpty())p="/home";
        final String target=p.trim();setStatus("Loading "+target+"…");
        io.execute(()->{try{
            Vector<?> entries=sftp.ls(target);ArrayList<String[]> items=new ArrayList<>();
            for(Object o:entries){ChannelSftp.LsEntry e=(ChannelSftp.LsEntry)o;String n=e.getFilename();if(n.equals(".")||n.equals(".."))continue;items.add(new String[]{n,e.getAttrs().isDir()?"D":"F"});}
            items.sort((a,b)->{if(a[1].equals(b[1]))return a[0].compareToIgnoreCase(b[0]);return a[1].equals("D")?-1:1;});
            currentPath=target;main.post(()->{path.setText(target);showExplorer(items);setStatus(items.size()+" items • "+target);});
        }catch(Exception e){setStatus("Browse error: "+e.getMessage());}});
    }
    void showExplorer(ArrayList<String[]> items){
        content.removeAllViews();terminalVisible=false;
        ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);
        TextView head=text("REMOTE FILES",11,MUTED);head.setPadding(8,8,8,8);list.addView(head);
        for(String[] item:items){LinearLayout rr=row();TextView name=text((item[1].equals("D")?"📁  ":"📄  ")+item[0],14,FG);name.setPadding(10,12,10,12);rr.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            rr.addView(button(item[1].equals("D")?"Open":"Edit",()->{String full=currentPath.replaceAll("/$","")+"/"+item[0];if(item[1].equals("D"))browse(full);else openFile(full);}));
            rr.setBackgroundColor(PANEL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,2,0,2);list.addView(rr,lp);}
        sc.addView(list);content.addView(sc,new LinearLayout.LayoutParams(-1,-1));
    }
    void goParent(){String p=currentPath;if(p==null||p.equals("/"))return;int i=p.lastIndexOf('/');browse(i<=0?"/":p.substring(0,i));}
    void openFile(String remote){
        if(!connected())return;setStatus("Opening "+remote+"…");
        io.execute(()->{try{InputStream in=sftp.get(remote);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>3*1024*1024)throw new IOException("File exceeds 3 MB preview limit");}
            String val=out.toString("UTF-8");main.post(()->activateTab(remote,val));setStatus("Opened "+remote);
        }catch(Exception e){setStatus("Open error: "+e.getMessage());}});
    }
    void activateTab(String name,String value){if(!openFiles.containsKey(name)){openFiles.put(name,value);tabOrder.add(name);}currentFile=name;undo.clear();redo.clear();showEditor();refreshTabs();setStatus(name);}
    void refreshTabs(){tabs.removeAllViews();for(String name:tabOrder){Button b=button(new File(name).getName()+(name.equals(currentFile)?" •":""),
        ()->{currentFile=name;undo.clear();redo.clear();showEditor();refreshTabs();});tabs.addView(b);}}
    void showEditor(){content.removeAllViews();terminalVisible=false;if(currentFile==null){TextView t=text("Connect to Debian, browse a folder, then open a file.",14,MUTED);t.setPadding(14,20,14,20);content.addView(t);return;}
        suppressWatch=true;editor.setText(openFiles.get(currentFile));editor.setSelection(editor.length());suppressWatch=false;content.addView(editor,new LinearLayout.LayoutParams(-1,-1));highlight();}
    void saveCurrent(){if(!connected()||currentFile==null){setStatus("No file open or not connected");return;}String name=currentFile,val=editor.getText().toString();setStatus("Saving…");
        io.execute(()->{try{sftp.put(new ByteArrayInputStream(val.getBytes("UTF-8")),name,ChannelSftp.OVERWRITE);setStatus("Saved "+name);}catch(Exception e){setStatus("Save error: "+e.getMessage());}});}
    void newFileDialog(){EditText input=edit("filename.txt",true);new AlertDialog.Builder(this).setTitle("Create remote file").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty())return;String full=currentPath.replaceAll("/$","")+"/"+n;io.execute(()->{try{sftp.put(new ByteArrayInputStream(new byte[0]),full);setStatus("Created "+full);browse(currentPath);}catch(Exception e){setStatus("Create error: "+e.getMessage());}});}).show();}
    void undoEdit(){if(undo.isEmpty())return;String cur=editor.getText().toString();redo.push(cur);String prev=undo.pop();suppressWatch=true;editor.setText(prev);editor.setSelection(editor.length());suppressWatch=false;openFiles.put(currentFile,prev);highlight();}
    void redoEdit(){if(redo.isEmpty())return;String cur=editor.getText().toString();undo.push(cur);String next=redo.pop();suppressWatch=true;editor.setText(next);editor.setSelection(editor.length());suppressWatch=false;openFiles.put(currentFile,next);highlight();}
    void highlight(){
        if(currentFile==null)return;String s=editor.getText().toString();if(s.length()>50000)return;
        SpannableString sp=new SpannableString(s);Pattern p=Pattern.compile("\\b(class|public|private|static|void|int|float|double|if|else|for|while|return|new|import|from|def|async|await|const|let|var|function|true|false|null|None|try|catch)\\b|(\"(?:\\\\.|[^\"])*\"|'(?:\\\\.|[^'])*')|//[^\\n]*|#[^\\n]*|\\b[0-9]+\\b");
        Matcher m=p.matcher(s);while(m.find()){int c=ORANGE;if(m.group(1)!=null)c=Color.rgb(147,197,253);else if(m.group(2)!=null)c=GREEN;else if(m.group().startsWith("//")||m.group().startsWith("#"))c=MUTED;sp.setSpan(new ForegroundColorSpan(c),m.start(),m.end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);}
        int pos=editor.getSelectionStart();suppressWatch=true;editor.setText(sp);if(pos>=0&&pos<=editor.length())editor.setSelection(pos);suppressWatch=false;
    }
    void toggleTerminal(){if(terminalVisible){browse(currentPath);return;}if(!connected()){setStatus("Connect SSH first");return;}startTerminal();}
    void startTerminal(){
        setStatus("Opening SSH terminal…");io.execute(()->{try{
            if(shell!=null)shell.disconnect();shell=(ChannelShell)session.openChannel("shell");shell.setPty(true);shell.setPtyType("xterm-256color",100,30,800,600);
            shellIn=shell.getOutputStream();shellOut=shell.getInputStream();shell.connect(8000);
            main.post(()->showTerminal());setStatus("Terminal connected");
            byte[] buf=new byte[4096];while(shell.isConnected()){while(shellOut.available()>0){int n=shellOut.read(buf);if(n>0){String out=new String(buf,0,n,"UTF-8");main.post(()->appendTerminal(out));}}Thread.sleep(80);}
        }catch(Exception e){setStatus("Terminal error: "+e.getMessage());}});
    }
    void showTerminal(){terminalVisible=true;content.removeAllViews();LinearLayout box=new LinearLayout(this);box.setOrientation(1);
        terminalOutput=text("",12,GREEN);terminalOutput.setTypeface(Typeface.MONOSPACE);terminalScroll=new ScrollView(this);terminalScroll.addView(terminalOutput);box.addView(terminalScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout r=row();terminalInput=edit("command…",true);r.addView(terminalInput,new LinearLayout.LayoutParams(0,48,1));r.addView(button("Send",()->sendCommand()));terminalInput.setOnEditorActionListener((v,a,e)->{sendCommand();return true;});box.addView(r);content.addView(box,new LinearLayout.LayoutParams(-1,-1));}
    void appendTerminal(String s){if(terminalOutput!=null){terminalOutput.append(s);terminalScroll.post(()->terminalScroll.fullScroll(View.FOCUS_DOWN));}}
    void sendCommand(){if(shellIn==null||terminalInput==null)return;String cmd=terminalInput.getText().toString();terminalInput.setText("");io.execute(()->{try{shellIn.write((cmd+"\n").getBytes("UTF-8"));shellIn.flush();}catch(Exception e){setStatus("Terminal send error: "+e.getMessage());}});}
    void readTerminal(){if(terminalVisible)setStatus("Terminal is live");}
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e.getAction()==KeyEvent.ACTION_DOWN&&e.isCtrlPressed()){
            if(e.getKeyCode()==KeyEvent.KEYCODE_S){saveCurrent();return true;}
            if(e.getKeyCode()==KeyEvent.KEYCODE_Z){undoEdit();return true;}
            if(e.getKeyCode()==KeyEvent.KEYCODE_Y){redoEdit();return true;}
        }
        return super.dispatchKeyEvent(e);
    }
    @Override public void onBackPressed(){if(terminalVisible){browse(currentPath);}else if(!currentPath.equals("/"))goParent();else super.onBackPressed();}
    @Override protected void onDestroy(){disconnect();io.shutdownNow();super.onDestroy();}
}
