# CodeBridge VS Code Client

تطبيق Android خفيف يفتح واجهة VS Code Server الحقيقية داخل WebView، وليس محرر SSH/SFTP منفصلًا.

## الاستخدام
- افتح التطبيق.
- العنوان الافتراضي: `http://192.168.1.10:8080`
- اضغط Open.
- يجب أن يكون الهاتف والتابلت على نفس الشبكة، وأن يكون code-server يعمل ويستمع على عنوان الشبكة.

## البناء
افتح المشروع في Android Studio أو استخدم GitHub Actions. الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- هذا التطبيق يعرض واجهة code-server الحقيقية عبر Android WebView. أداء WebView يعتمد على إصدار Android WebView والجهاز.
- إذا لم يفتح الرابط من المتصفح على التابلت، فلن يفتحه التطبيق أيضًا.
- لا تعرّض code-server أو SSH للإنترنت دون HTTPS ومصادقة قوية. استخدمه على شبكة موثوقة.
