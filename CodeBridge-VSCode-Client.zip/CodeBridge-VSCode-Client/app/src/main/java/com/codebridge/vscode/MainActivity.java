package com.codebridge.vscode;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout root, bar;
    private boolean immersive = false;
    private static final String DEFAULT_URL = "http://192.168.1.10:8080";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildUi();
        configureWebView();
        if (state == null) load(DEFAULT_URL);
        else web.restoreState(state);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(13); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48,112,220)));
        b.setOnClickListener(v -> action.run()); return b;
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(17,24,39));
        bar = new LinearLayout(this); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(5),dp(3),dp(5),dp(3));
        address = new EditText(this); address.setSingleLine(true); address.setTextColor(Color.WHITE); address.setHintTextColor(0xff9ca3af);
        address.setHint("VS Code Server URL"); address.setText(DEFAULT_URL); address.setTextSize(14);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, id, event) -> { if (id == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode()==KeyEvent.KEYCODE_ENTER)) { load(address.getText().toString()); return true; } return false; });
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        bar.addView(button("Open", () -> load(address.getText().toString())), new LinearLayout.LayoutParams(dp(76),dp(44)));
        root.addView(bar, new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setPadding(dp(4),0,dp(4),dp(3));
        controls.addView(button("Back", () -> { if(web.canGoBack()) web.goBack(); }), new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("Forward", () -> { if(web.canGoForward()) web.goForward(); }), new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("Reload", () -> web.reload()), new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("Full", () -> toggleImmersive()), new LinearLayout.LayoutParams(0,dp(42),1));
        root.addView(controls);
        web = new WebView(this); web.setBackgroundColor(Color.rgb(17,24,39));
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setMediaPlaybackRequiresUserGesture(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false); s.setUseWideViewPort(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public void onPageFinished(WebView view, String url) { address.setText(url); }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setFocusable(true); web.setFocusableInTouchMode(true);
    }

    private void load(String raw) {
        if (raw == null) return;
        String url = raw.trim();
        if (url.isEmpty()) return;
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://" + url;
        address.setText(url); web.loadUrl(url);
    }

    private void toggleImmersive() {
        immersive = !immersive;
        if (immersive) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            bar.setVisibility(View.GONE);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            bar.setVisibility(View.VISIBLE);
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if(web != null) web.saveState(out); }
    @Override protected void onDestroy() { if(web != null) { web.stopLoading(); web.destroy(); } super.onDestroy(); }
}
