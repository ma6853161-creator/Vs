# DeviceBridge (Android)

An independently written, ad-free Android project foundation inspired by the general device-management workflow of ADB companion apps. It does **not** contain Bugjaeger's proprietary code, assets, or branding.

## Current status — important

This repository currently builds an installable Android APK with a simple native dashboard. It is a **starter foundation, not a completed Bugjaeger replacement**. USB ADB, wireless ADB pairing/authentication, shell transport, Fastboot, remote file transfer, package management, Logcat streaming, process monitoring, screenshot capture, and screen mirroring are listed in the UI but are not implemented in this initial build. Do not use it as if those tools are operational.

The supplied `Bugjaeger 10.8.apk+` is an APK bundle containing `base.apk` and split APKs. Its metadata identifies package `eu.sisik.hackendebug`, version `10.8`, and minimum Android API 24. This project uses a new package ID (`com.devicebridge.app`) and does not modify or redistribute the original application.

## Build on GitHub (no local computer required)

1. Create a new empty GitHub repository.
2. Extract this ZIP and upload **the contents** of this folder to the repository root (make sure `.github/workflows/android.yml` is included).
3. Open the repository's **Actions** tab and enable workflows if GitHub asks.
4. Run **Build Android APK** (or push to `main`/`master`).
5. Open the completed workflow run. Under **Artifacts**, download `DeviceBridge-debug-apk` and extract `app-debug.apk`.
6. Install the APK on your Android device. This is a debug-signed build.

## Build locally

Requires JDK 17, Android SDK Platform 35 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Privacy / ads

No advertising SDK, analytics SDK, tracking permission, or ad network dependency is included in this project.

## Roadmap for a functional device toolkit

- Implement ADB host protocol, RSA key management and wireless pairing/authentication.
- Implement USB host transport and device permission flow.
- Implement shell, sync/file transfer, package manager, logcat and device information modules.
- Implement Fastboot separately with compatible USB transport.
- Add screenshot/screen streaming and process monitoring.
- Add automated tests against authorized test devices before marking features complete.

Only connect to devices you own or are authorized to administer.
