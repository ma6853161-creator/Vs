package com.devicebridge.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * DeviceBridge is an independently written, ad-free Android project scaffold.
 * The ADB protocol/USB transport is intentionally not faked: feature cards
 * identify the planned modules until their real transports are implemented.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 40)
    private val panel = Color.rgb(31, 41, 55)
    private val muted = Color.rgb(156, 163, 175)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        setContentView(buildScreen())
    }

    private fun buildScreen(): android.view.View {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(root)

        root.addView(text("DEVICEBRIDGE", 13f, Color.rgb(129, 140, 248), true))
        root.addView(text("Android device toolkit", 27f, white, true).apply {
            setPadding(0, dp(8), 0, dp(5))
        })
        root.addView(text("An ad-free, independent ADB companion project.", 14f, muted))

        val status = card()
        status.addView(text("CONNECTION", 12f, muted, true))
        status.addView(text("No ADB transport connected", 18f, white, true).apply {
            setPadding(0, dp(9), 0, dp(5))
        })
        status.addView(text("The current build is the deployable project foundation. USB and wireless ADB protocol support is not implemented yet.", 13f, muted))
        root.addView(status)

        root.addView(text("TOOLS", 12f, muted, true).apply { setPadding(0, dp(22), 0, dp(8)) })
        val features = listOf(
            "ADB Shell" to "Terminal interface — transport pending",
            "Wireless ADB" to "Pairing and TCP connection — pending",
            "USB ADB" to "USB host transport — pending",
            "App Manager" to "Install, uninstall and package inspection — pending",
            "File Manager" to "Browse and transfer remote files — pending",
            "Logcat" to "Read and filter device logs — pending",
            "Process Monitor" to "Process and resource monitoring — pending",
            "Fastboot" to "Bootloader protocol — pending",
            "Screen Tools" to "Capture and mirroring — pending",
            "Custom Commands" to "Saved command presets — pending"
        )
        features.forEach { (name, detail) ->
            val item = card()
            item.addView(text(name, 16f, white, true))
            item.addView(text(detail, 12f, muted).apply { setPadding(0, dp(5), 0, 0) })
            root.addView(item)
        }

        val info = Button(this).apply {
            text = "PROJECT STATUS"
            isAllCaps = false
            setTextColor(white)
            setBackgroundColor(Color.rgb(66, 99, 235))
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("DeviceBridge 0.1.0")
                    .setMessage("Ad-free Android project foundation. This APK builds and installs, but it is not yet a functional Bugjaeger replacement. ADB transports and tool modules must be implemented and tested before claiming feature parity.")
                    .setPositiveButton("OK", null).show()
            }
        }
        root.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply {
            topMargin = dp(14)
        })
        root.addView(text("No ads • No analytics SDK • Min Android 7.0", 12f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        return scroll
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(9)
        layoutParams = lp
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
